class Game(object):
    def __init__(self):
        self.__score__ = 0

    def roll(self, pins):
        self.__score__ += pins

    def score(self):
        return self.__score__

# Execute
if __name__ == '__main__':
    game = Game()
    for i in range(0, 20):
        game.roll(0)
    print(game.score())
import unittest
from app.bowling_game import Game

class BowlingGameTest(unittest.TestCase):
    # execute before every test
    def setUp(self):
        self.g = Game()

    # 1st Test
    def test_gutter_game(self):
        for i in range(0, 20):
            self.g.roll(0)
        self.assertEqual(0, self.g.score())

if __name__ == '__main__':
    unittest.main()
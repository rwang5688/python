class Game(object):
    def __init__(self):
        self.__rolls__ = [0, 0, 0, 0, 0,
                        0, 0, 0, 0, 0,
                        0, 0, 0, 0, 0,
                        0, 0, 0, 0, 0,
                        0]
        self.__currentRoll__ = 0

    # keep track of rolls
    def roll(self, pins):
        self.__rolls__[self.__currentRoll__] = pins
        self.__currentRoll__ += 1

    # calculate score
    def score(self):
        score = 0
        rollIndex = 0
        for frame in range(0, 10):
            if self.is_spare(rollIndex):
                score += 10 + self.spare_bonus(rollIndex)
                rollIndex += 2
            else:
                score += self.sum_of_balls_in_frame(rollIndex)
                rollIndex += 2
        return score

    # game rules
    def is_spare(self, rollIndex):
        return self.__rolls__[rollIndex] + self.__rolls__[rollIndex+1] == 10

    def spare_bonus(self, rollIndex):
        return self.__rolls__[rollIndex+2]

    def sum_of_balls_in_frame(self, rollIndex):
        return self.__rolls__[rollIndex] + self.__rolls__[rollIndex+1]

# Execute
if __name__ == '__main__':
    g = Game()
    g.roll(10) # strike
    g.roll(3)  # strike bonus
    g.roll(4)  # strike bonus
    for i in range(0, 16):
        g.roll(0)
    print(g.score())

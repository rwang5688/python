class Game(object):
    def __init__(self):
        self.__score__ = 0

    def roll(self, pins):
        self.__score__ += pins

    def score(self):
        return self.__score__

# Execute
if __name__ == '__main__':
    g = Game()
    g.roll(5)
    g.roll(5)
    g.roll(3)  # spare bonus
    for i in range(0, 16):
        g.roll(0)
    print(g.score())
